Guidelines how to use the code:

The code requires the following Python software packages: 

- numpy 
- argparse
- math
- pyplot
- cv2 (Open CV Pythin distribution)
- open source implementation of the iterative closest point (ICP) method (icp.py) from: 
	- from https://github.com/ClayFlannigan/icp

Moreover, the CT scans of the two walls were conducted on:

A CT-Compact of the manufacturer “ProCon X-Ray GmbH” which is part of the Shared Laboratory C of the livMatS Cluster, 
Funded by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation)
under Germany’s Excellence Strategy–EXC-2193/1 – 390951807.


Execution of the code:

The code can be executed using python3 via: 

python3 image_analysis.py
