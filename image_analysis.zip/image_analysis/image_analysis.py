# The following code provides the image analysis of the CT scans of printed sloping walls
# conducted in Section 13. 

# It was developed by Steve Wolff-Vorbeck in collaboration with Alexander Schulz both from the University of Freiburg

# Further comments:
 
# 1. The image analysis in the example is restricted to 4 slices of slopung wall P1 in Section 13.

# 2. The code uses the open source implementation on the iterative closest point (ICP) method from: 
# https://github.com/ClayFlannigan/icp

# 3. The CT scans of the two walls were conducted on:

# A CT-Compact of the manufacturer “ProCon X-Ray GmbH” which is part of the Shared Laboratory C of the livMatS Cluster, 
# Funded by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation)
# under Germany’s Excellence Strategy–EXC-2193/1 – 390951807.

import numpy as np
import cv2
from matplotlib import pyplot as plt
import argparse
import math as ma
import icp


def rect1(t,a,b):
	if abs(ma.tan(t))<= b/a:
		return (a/abs(ma.cos(t)))
	else:
		return (b/abs(ma.sin(t)))

		
scal1=3086.0
scal2=0.6469700237222342
a1=1/12
a2=1/3
scal=(1/(scal1*scal2))

# Lengths of the first slopy wall of the first sample
L1=1994
L2=434
L4=330
L3=L1+L4
L5=2324
#l2=int((float(L5)-float(L2))/5.0)
l2=4

xs1=np.zeros(l2)
xs2=np.zeros(l2)
s1=np.zeros(l2)
s2=np.zeros(l2)

points1=[]
points2=[]
count=np.zeros(l2)
count2=np.zeros(l2)
t=0
b=0

# Loading pictures and determine contour, contours are then saved in points1 and points2 (x and y coordinates)
for i in range(0,l2):
	t=i*400+L2
	b=i
	print(t)
	
	img = cv2.imread(str(10000+t)+'.bmp')
	
	dst = cv2.fastNlMeansDenoising(img,None,100,7,27)
	gray = cv2.cvtColor(dst, cv2.COLOR_BGR2GRAY)
	_, binary = cv2.threshold(gray, 55, 55, 0)

	M = cv2.moments(binary)
	cX = int(M["m10"] / M["m00"])
	cY = int(M["m01"] / M["m00"])
	
	# center of mass is computed for each slice
	xs1[i]+=cX
	xs2[i]+=cY
	
	#compute exact slopy wall (this belongs to wall1)
	if (float(t-L4))> float(0.1*L1):
		s1[i]+= 0.5*((float(t-L4)/float(L1))*0.0607-0.0894+a1)
		
	
	contours, hierarnchy = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
	img = cv2.drawContours(img, contours, -1, (0, 255, 0), 2)
	cv2.circle(img, (cX, cY), 5, (255, 255, 255), -1)
	
	# show the image with the drawn contours
	plt.imshow(img)
	plt.show()
	
	# Compute length of the contour. There is a better way!!
	l1=0
	for n in range(0, len(contours)):
  
		for j in range(0, len(contours[n])):
			l1+=1

	# Put contour-points in arrays points1 and points2
	pts1 = np.zeros(l1)
	pts2 = np.zeros(l1)
	count[i]+=l1
	k=0
	for n in range(0, len(contours)):
  
		for j in range(0, len(contours[n])):
			pts1[k]+=float(contours[n][j][0][0])
			pts2[k]+=float(contours[n][j][0][1])
			k+=1
	
	for n in range(0,l1,20):
		points1.append(pts1[n])
		points2.append(pts2[n])
		count2[i]+=1



# All contours are now computed and points are included in points1 and points2
# Now determine rotation of the whole wall 
#This uses the icp-algorithm from:
# https://github.com/ClayFlannigan/icp

ttt1=int(count2[0])
A=np.zeros((ttt1,2))
B=np.zeros((ttt1,2))
xs1*=scal
xs2*=scal

for i in range(0,ttt1):

		A[i][0]+=(scal*points1[i]-xs1[0])
		A[i][1]+=(scal*points2[i]-xs2[0])
		theta2=np.arctan2(A[i][0],A[i][1])
		if A[i][0]> 0 and A[i][1]> 0:
			B[i][0]+=ma.cos(0.5*ma.pi-abs(theta2))*rect1(0.5*ma.pi-abs(theta2),a1-s1[0],a2)
			B[i][1]+=ma.sin(0.5*ma.pi-abs(theta2))*rect1(0.5*ma.pi-abs(theta2),a1-s1[0],a2)

		elif A[i][0]< 0 and A[i][1] > 0:
			B[i][0]+=ma.cos(0.5*ma.pi+abs(theta2))*rect1(0.5*ma.pi+abs(theta2),a1-s1[0],a2)
			B[i][1]+=ma.sin(0.5*ma.pi+abs(theta2))*rect1(0.5*ma.pi+abs(theta2),a1-s1[0],a2)
			
			
		elif A[i][0] < 0 and A[i][1] < 0:
			B[i][0]+=ma.cos(0.5*ma.pi+abs(theta2))*rect1(0.5*ma.pi+abs(theta2),a1-s1[0],a2)
			B[i][1]+=ma.sin(0.5*ma.pi+abs(theta2))*rect1(0.5*ma.pi+abs(theta2),a1-s1[0],a2)

		else:
			B[i][0]+=ma.cos(2.5*ma.pi-abs(theta2))*rect1(2.5*ma.pi-abs(theta2),a1-s1[0],a2)
			B[i][1]+=ma.sin(2.5*ma.pi-abs(theta2))*rect1(2.5*ma.pi-abs(theta2),a1-s1[0],a2) 	
		

T, distances, iterations = icp.icp(A, B, tolerance=0.000001)

# Open files to save parameters from warping and LSQ errors
datei1 = open('x_s_extend.txt','w')
datei2 = open('y_s_extend.txt','w')
dateierr = open('LSQ_extend.txt','w')

cc=0

for i in range(0,l2):		
	ttt=int(count2[i])
	
	t1=np.zeros(ttt)
	t2=np.zeros(ttt)
	tt1=np.zeros(ttt)
	tt2=np.zeros(ttt)
	ee1=np.ones(ttt)

	t_ex1=np.zeros(ttt)
	t_ex2=np.zeros(ttt)
	
	# Preparing matching-points for regression! There is a better way!!	Shift arctan?
	for j in range(0,ttt):
		t1[j]+=T[0][0]*(scal*points1[j+cc]-xs1[i])+T[0][1]*(scal*points2[j+cc]-xs2[i])
		t2[j]+=T[1][0]*(scal*points1[j+cc]-xs1[i])+T[1][1]*(scal*points2[j+cc]-xs2[i])
		theta=np.arctan2(t1[j],t2[j])
		
		if t1[j]> 0 and t2[j]> 0:
			t_ex1[j]+=ma.cos(0.5*ma.pi-abs(theta))*rect1(0.5*ma.pi-abs(theta),a1-s1[i],a2)
			t_ex2[j]+=ma.sin(0.5*ma.pi-abs(theta))*rect1(0.5*ma.pi-abs(theta),a1-s1[i],a2)

		elif t1[j]< 0 and t2[j] > 0:
			t_ex1[j]+=ma.cos(0.5*ma.pi+abs(theta))*rect1(0.5*ma.pi+abs(theta),a1-s1[i],a2)
			t_ex2[j]+=ma.sin(0.5*ma.pi+abs(theta))*rect1(0.5*ma.pi+abs(theta),a1-s1[i],a2)
			
			
		elif t1[j] < 0 and t2[j] < 0:
			t_ex1[j]+=ma.cos(0.5*ma.pi+abs(theta))*rect1(0.5*ma.pi+abs(theta),a1-s1[i],a2)
			t_ex2[j]+=ma.sin(0.5*ma.pi+abs(theta))*rect1(0.5*ma.pi+abs(theta),a1-s1[i],a2)

		else: 
			print(theta)
			t_ex1[j]+=ma.cos(2.5*ma.pi-abs(theta))*rect1(2.5*ma.pi-abs(theta),a1-s1[i],a2)
			t_ex2[j]+=ma.sin(2.5*ma.pi-abs(theta))*rect1(2.5*ma.pi-abs(theta),a1-s1[i],a2)
			
			
	# direct approach to find parameters for warping (linear case)
	mat2=np.zeros((len(t_ex1),2))
	mat3=np.zeros((2,len(t_ex1)))
	
	for k in range(0,len(t_ex1)):
		mat2[k][0]+=t_ex1[k]
		mat2[k][1]+=t_ex2[k]	
			
			
	mat3+=mat2.transpose()
	A= np.matmul(mat3,mat2)	
	Av=np.linalg.inv(A)
	X=np.matmul(Av,mat3)
	x111= X.dot(t1)
	x222= X.dot(t2)
	#I=np.matmul(A,Av)
	
	print(x111)
	print(x222)

	# Prepare array to plot the transformation
	for j in range(0,ttt):	
		tt1[j]+= x111[0]*t_ex1[j]+x111[1]*t_ex2[j]
		tt2[j]+= x222[0]*t_ex1[j]+x222[1]*t_ex2[j]
		
	
	# Save parameters and LSQ-errors
	for k in range(0,2):
		datei1.write(str(x111[k]))
		datei1.write(" ")
		datei2.write(str(x222[k]))
		datei2.write(" ")
		dateierr.write(str(np.dot(t1-tt1,t1-tt1)+np.dot(t2-tt2,t2-tt2)))
		dateierr.write( " ")	
	datei1.write('\n')
	datei2.write('\n')
	dateierr.write('\n')
			 			
	cc+=ttt
	
	#Plotting exact, perturbed and transformed contours as pointclouds
	plt.plot(t1,t2,'o')
	plt.plot(tt1,tt2,'o')
	print(np.dot(t1-tt1,t1-tt1)+np.dot(t2-tt2,t2-tt2))
	plt.plot(t_ex1,t_ex2)
	plt.show()
