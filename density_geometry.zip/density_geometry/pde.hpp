#ifndef __PDE_HPP__
#define __PDE_HPP__

#include <string>
#include "mesh.hpp"

#include <thread>
#include <mutex>

#include <Eigen/Sparse>
#include<Eigen/SparseCholesky>
#include <Eigen/Core>
#include <unsupported/Eigen/Splines>

struct ElMod {
	
	inline ElMod() {}
	inline ElMod(double, double);
	
	inline double& operator ()(int i, int j, int k, int l) { return C[i][j][k][l]; }
	inline double operator ()(int i, int j, int k, int l) const { return C[i][j][k][l]; }
	
	double C[3][3][3][3];

};

class ImplicitPDESystem {
public:
	
    typedef Eigen::VectorXd Vec;
    //typedef Eigen::SparseMatrix<double, Eigen::RowMajor> SpMat;
    typedef Eigen::SparseMatrix<double, Eigen::ColMajor> SpMat;
    typedef Eigen::Triplet<double> T;
    typedef Eigen::MatrixXd Mat;
    typedef Eigen::SimplicialLDLT<SpMat> SpSolver; 
    inline ImplicitPDESystem( Mesh* mesh ) : m(mesh) { }
   
	void InitU_Scal(); 
  	void Init1(std::string);
  	void Init2(std::string);
	
	void Init_Corr_len(double);
  	void Assemble();
	void Perform_Geo_Per();
  	void Solve();
	void SolveWithGuess();
	
	void CalcYoungs(int);
	void Export_Vol(std::string) const;
	void Export_Surface(std::string) const;
	void Export_Scal(std::string) const;
	void SaveFace(std::string) const;
	void Init_Sigma0(double,double);
	void Init_Sigma1(double,double);
	void Init_Sigma2(double,double);
	void CholeskyLoop();
	void Geo_CholeskyLoop();
   
private:
	void CalcFNeu();
    	void SetBC();
	void InitBC();
	
	Vec3 NeumannBC(Vec3) const; 
	void LoadOptions(std::string);

 	void PrepK();
 	void Prep_Norm();
  	void KLoop( SpMat*,SpMat*, Vec*,Vec*, Mesh::TetIt, Mesh::TetIt);
  	void Init_Coords();
	
  	void ELoop ( double*, Mesh::TetIt, Mesh::TetIt );
  	double CalcE();

  // Access to the basis functions, etc.
  Mesh* m;
    
  // basis functions (that are not constrained) and elements
  int N_dof, N_tet;
  
  // mutexes and threading
  mutable std::vector<std::mutex> idx_mutex;
  mutable std::mutex mut;
  std::vector<std::pair<Mesh::TetIt, Mesh::TetIt> > tet_th;
 
  // general params
 //int numThreads=4; // number of threads
  int numThreads=1; // number of threads
  
  ElMod C;
  double bottom, top, bottom_var, top_var;
  double area, len;
  double l_c1,kernel_b;
  int m_size,long_len; 
  double sigma_new1,sigma_new2,sigma_scal1,sigma_scal2,sigma_shear1,sigma_shear2;

  //minimization data
  Vec B, B1, FNeu;
  Vec X1_new,X2_new,X3_new,Coords;
  Vec Z, U_Db,X1,X2,X3,X_Coord,Y_Coord,Z_Coord,Z0,U_Scal,C_lognorm,C_norm1,C_norm2,C_norm3,C_norm4,C_norm_scal1,C_norm_scal2, C_norm_shear1,C_norm_shear2,C_norm_trans1,C_norm_trans2;
  Vec X1_scal,Y1_scal,X1_shear,Y1_shear;
  SpMat K,KTL,KTL_Chol,Test_Matrix,SIG1,SIG2,SIG3,K_delta;

  Mat KTL_new1, KTL_new2,KTL_new_scal,KTL_new_shear;
  Mat KTL_Cholnew1,KTL_Cholnew2,KTL_Cholnew_shear,KTL_Cholnew_scal;
  std::vector<double> mesh_sizes; 

};

inline ElMod::ElMod(double K, double mu) {
	C[0][0][0][0] = K+mu+mu-2.0/3.0*mu;
	C[0][0][0][1] = 0.0;
	C[0][0][0][2] = 0.0;
	C[0][0][1][0] = 0.0;
	C[0][0][1][1] = K-2.0/3.0*mu;
	C[0][0][1][2] = 0.0;
	C[0][0][2][0] = 0.0;
	C[0][0][2][1] = 0.0;
	C[0][0][2][2] = K-2.0/3.0*mu;
	
	C[0][1][0][0] = 0.0;
	C[0][1][0][1] = mu;
	C[0][1][0][2] = 0.0;
	C[0][1][1][0] = mu;
	C[0][1][1][1] = 0.0;
	C[0][1][1][2] = 0.0;
	C[0][1][2][0] = 0.0;
	C[0][1][2][1] = 0.0;
	C[0][1][2][2] = 0.0;
	
	C[0][2][0][0] = 0.0;
	C[0][2][0][1] = 0.0;
	C[0][2][0][2] = mu;
	C[0][2][1][0] = 0.0;
	C[0][2][1][1] = 0.0;
	C[0][2][1][2] = 0.0;
	C[0][2][2][0] = mu;
	C[0][2][2][1] = 0.0;
	C[0][2][2][2] = 0.0;
	
	C[1][0][0][0] = 0.0;
	C[1][0][0][1] = mu;
	C[1][0][0][2] = 0.0;
	C[1][0][1][0] = mu;
	C[1][0][1][1] = 0.0;
	C[1][0][1][2] = 0.0;
	C[1][0][2][0] = 0.0;
	C[1][0][2][1] = 0.0;
	C[1][0][2][2] = 0.0;
	
	C[1][1][0][0] = K-2.0/3.0*mu;
	C[1][1][0][1] = 0.0;
	C[1][1][0][2] = 0.0;
	C[1][1][1][0] = 0.0;
	C[1][1][1][1] = K+mu+mu-2.0/3.0*mu;
	C[1][1][1][2] = 0.0;
	C[1][1][2][0] = 0.0;
	C[1][1][2][1] = 0.0;
	C[1][1][2][2] = K-2.0/3.0*mu;
	
	C[1][2][0][0] = 0.0;
	C[1][2][0][1] = 0.0;
	C[1][2][0][2] = 0.0;
	C[1][2][1][0] = 0.0;
	C[1][2][1][1] = 0.0;
	C[1][2][1][2] = mu;
	C[1][2][2][0] = 0.0;
	C[1][2][2][1] = mu;
	C[1][2][2][2] = 0.0;
	
	C[2][0][0][0] = 0.0;
	C[2][0][0][1] = 0.0;
	C[2][0][0][2] = mu;
	C[2][0][1][0] = 0.0;
	C[2][0][1][1] = 0.0;
	C[2][0][1][2] = 0.0;
	C[2][0][2][0] = mu;
	C[2][0][2][1] = 0.0;
	C[2][0][2][2] = 0.0;
	
	C[2][1][0][0] = 0.0;
	C[2][1][0][1] = 0.0;
	C[2][1][0][2] = 0.0;
	C[2][1][1][0] = 0.0;
	C[2][1][1][1] = 0.0;
	C[2][1][1][2] = mu;
	C[2][1][2][0] = 0.0;
	C[2][1][2][1] = mu;
	C[2][1][2][2] = 0.0;
	
	C[2][2][0][0] = K-2.0/3.0*mu;
	C[2][2][0][1] = 0.0;
	C[2][2][0][2] = 0.0;
	C[2][2][1][0] = 0.0;
	C[2][2][1][1] = K-2.0/3.0*mu;
	C[2][2][1][2] = 0.0;
	C[2][2][2][0] = 0.0;
	C[2][2][2][1] = 0.0;
	C[2][2][2][2] = K+mu+mu-2.0/3.0*mu;
	
	/*	C[0][0][0][0] = 1.0;
		C[0][0][0][1] = 0.0;
		C[0][0][0][2] = 0.0;
		C[0][0][1][0] = 0.0;
		C[0][0][1][1] = 0.0;
		C[0][0][1][2] = 0.0;
		C[0][0][2][0] = 0.0;
		C[0][0][2][1] = 0.0;
		C[0][0][2][2] = 0.0;
	
		C[0][1][0][0] = 0.0;
		C[0][1][0][1] = 1.0;
		C[0][1][0][2] = 0.0;
		C[0][1][1][0] = 0.0;
		C[0][1][1][1] = 0.0;
		C[0][1][1][2] = 0.0;
		C[0][1][2][0] = 0.0;
		C[0][1][2][1] = 0.0;
		C[0][1][2][2] = 0.0;
	
		C[0][2][0][0] = 0.0;
		C[0][2][0][1] = 0.0;
		C[0][2][0][2] = 1.0;
		C[0][2][1][0] = 0.0;
		C[0][2][1][1] = 0.0;
		C[0][2][1][2] = 0.0;
		C[0][2][2][0] = 0.0;
		C[0][2][2][1] = 0.0;
		C[0][2][2][2] = 0.0;
	
		C[1][0][0][0] = 0.0;
		C[1][0][0][1] = 0.0;
		C[1][0][0][2] = 0.0;
		C[1][0][1][0] = 1.0;
		C[1][0][1][1] = 0.0;
		C[1][0][1][2] = 0.0;
		C[1][0][2][0] = 0.0;
		C[1][0][2][1] = 0.0;
		C[1][0][2][2] = 0.0;
	
		C[1][1][0][0] = 0.0;
		C[1][1][0][1] = 0.0;
		C[1][1][0][2] = 0.0;
		C[1][1][1][0] = 0.0;
		C[1][1][1][1] = 1.0;
		C[1][1][1][2] = 0.0;
		C[1][1][2][0] = 0.0;
		C[1][1][2][1] = 0.0;
		C[1][1][2][2] = 0.0;
	
		C[1][2][0][0] = 0.0;
		C[1][2][0][1] = 0.0;
		C[1][2][0][2] = 0.0;
		C[1][2][1][0] = 0.0;
		C[1][2][1][1] = 0.0;
		C[1][2][1][2] = 1.0;
		C[1][2][2][0] = 0.0;
		C[1][2][2][1] = 0.0;
		C[1][2][2][2] = 0.0;
	
		C[2][0][0][0] = 0.0;
		C[2][0][0][1] = 0.0;
		C[2][0][0][2] = 0.0;
		C[2][0][1][0] = 0.0;
		C[2][0][1][1] = 0.0;
		C[2][0][1][2] = 0.0;
		C[2][0][2][0] = 1.0;
		C[2][0][2][1] = 0.0;
		C[2][0][2][2] = 0.0;
	
		C[2][1][0][0] = 0.0;
		C[2][1][0][1] = 0.0;
		C[2][1][0][2] = 0.0;
		C[2][1][1][0] = 0.0;
		C[2][1][1][1] = 0.0;
		C[2][1][1][2] = 0.0;
		C[2][1][2][0] = 0.0;
		C[2][1][2][1] = 1.0;
		C[2][1][2][2] = 0.0;
	
		C[2][2][0][0] = 0.0;
		C[2][2][0][1] = 0.0;
		C[2][2][0][2] = 0.0;
		C[2][2][1][0] = 0.0;
		C[2][2][1][1] = 0.0;
		C[2][2][1][2] = 0.0;
		C[2][2][2][0] = 0.0;
		C[2][2][2][1] = 0.0;
		C[2][2][2][2] = 1.0; */
	
}

#endif
