#include <iostream>
#include <fstream>
#include <vector>
#include <iostream>
#include <string>
#include <random>
#include <ctime>        // std::time
#include <cstdlib>     
#include <algorithm> 
#include <cmath> 
using namespace std;
#include "pde.hpp"
#include "mesh.hpp"
#include "vertex.hpp"
#include "tmv.hpp"

using namespace Eigen;

#include "boost/tokenizer.hpp"
#include <Eigen/Core>
#include <Eigen/SparseCore>
#include <Eigen/Sparse>
#include <Eigen/IterativeLinearSolvers>

const double mu_scal1=0.0;
const double mu_scal2=0.0;
const double mu_shear1=0.0;
const double mu_shear2=0.0;
const double lc_dens=0.006615;

	// Generators for the distributions
	std::default_random_engine generator_lognorm; 
	std::default_random_engine generator_norm1;
	std::default_random_engine generator_norm2;
	std::default_random_engine generator_norm_scal1;
	std::default_random_engine generator_norm_scal2;
	std::default_random_engine generator_norm_shear1;
	std::default_random_engine generator_norm_shear2;

					
	// generator for standard normal distribution
 	std::normal_distribution<double> distribution_norm1(0.0,1.0);
 	
 	// generator for log-normal distribution
 	std::default_random_engine generator_log;
  	std::lognormal_distribution<double> distribution_log(-3.6243,0.5932);


inline double pos_part(double s)
{
		if (s>=0) {return s;} 

		else

		return 0.0; 
	}


inline double GKernel_Smoothing(std::vector<double> th1, std::vector<double> th2, double s, double b) {

		int length = th2.size();		
		double b1= length-1;
		double M=0.0;
		double N= 0.0; 	
		double scal=1/b;	

			for (int i=0; i < length; ++i) {
				
				M+= exp(-0.5*sqr(th1[i]-s)/sqr(scal));
				N+= exp(-0.5*sqr(th1[i]-s)/sqr(scal))*th2[i];
				
			} 					
			
				N*=(1/M);
				
				return N; 

}

         
void ImplicitPDESystem::Init_Coords(){
		X_Coord=Vec::Zero(m->VertexSize());	
		Y_Coord=Vec::Zero(m->VertexSize());
		Z_Coord=Vec::Zero(m->VertexSize());

auto vi = m->VertexBegin(), ve = m->VertexEnd();


	for (; vi!=ve; ++vi) {
		
	        double x = (*vi)->x();
	        double y = (*vi)->y();
		double z = (*vi)->z();
					

					int idx = (*vi)->Index_ref();
					X_Coord[idx]=x;
					Y_Coord[idx]=y;
					Z_Coord[idx]=z;
			

							}
}


void ImplicitPDESystem::Init_Corr_len(double l1) { 

		double *l1p;
		l1p=&l_c1;
		*l1p= l1;
		
				
}

void ImplicitPDESystem::Init_Sigma0(double sigma1, double sigma2) { 

		double *sigma1p, *sigma2p;
		sigma1p=&sigma_new1;
		*sigma1p= sigma1;
		
		sigma2p=&sigma_new2;
		*sigma2p=sigma2;
		
}

void ImplicitPDESystem::Init_Sigma1(double sigma1, double sigma2) { 

		double *sigma1p, *sigma2p;
		sigma1p=&sigma_scal1;
		*sigma1p= sigma1;
		
		sigma2p=&sigma_scal2;
		*sigma2p=sigma2;		
}


void ImplicitPDESystem::Init_Sigma2(double sigma1, double sigma2) { 

		double *sigma1p, *sigma2p;
		sigma1p=&sigma_shear1;
		*sigma1p= sigma1;
		
		sigma2p=&sigma_shear2;
		*sigma2p=sigma2;
		
}			


void ImplicitPDESystem::SetBC() {
	
	Mesh::VertexIt vi = m->BdryVertexBegin(), ve = m->BdryVertexEnd();
	bool fix1 = false, fix2 = false;
	for (; vi!=ve; ++vi ) {
		double z = (*vi)->z();
		if (z<bottom+bottom_var) {
			if ( (!fix2) & fix1 ) {
				(*vi)->MarkDirBdry1();
				fix2 = true;
			}
			if ( !fix1 ) {			
				(*vi)->MarkDirBdry1();
				(*vi)->MarkDirBdry2();
				fix1 = true;
			}
			//(*vi)->MarkDirBdry1();
			//(*vi)->MarkDirBdry2();
			(*vi)->MarkDirBdry3();
		}
		if (z>top-top_var) {
			(*vi)->MarkDirBdry3();
		}
	}
	
	Mesh::FaceIt fi = m->BdryFaceBegin(), fe = m->BdryFaceEnd();
	for (; fi!=fe; ++fi) 
		for (int j=0; j<3; ++j)
			if (!(*fi)->a()->DirBdry(j) || !(*fi)->b()->DirBdry(j) || !(*fi)->c()->DirBdry(j))
				(*fi)->MarkNeuBdry(j);
	
}

Vec3 ImplicitPDESystem::NeumannBC(Vec3 coord) const {
	return Vec3(0.0,0.0,0.0);
}

void ImplicitPDESystem::InitBC() {
	
	Mesh::VertexIt vi = m->BdryVertexBegin(), ve = m->BdryVertexEnd();
	for (; vi!=ve; ++vi ) {
		double z = (*vi)->z();
		if (z<bottom+2.0*bottom_var) {
			if ((*vi)->DirBdry1()) (*vi)->u1() = 0.0;
			if ((*vi)->DirBdry2()) (*vi)->u2() = 0.0;
			if ((*vi)->DirBdry3()) (*vi)->u3() = 0.0;
		} else {
			if ((*vi)->DirBdry1()) (*vi)->u1() = 0.0;
			if ((*vi)->DirBdry2()) (*vi)->u2() = 0.0;
			if ((*vi)->DirBdry3()) (*vi)->u3() = -0.5;
		}
		
	}
}



void ImplicitPDESystem::Init1(std::string config_file) {
	
	//assert(config_file!="");
	// first thing, if we are given a file to init from, we load this data
	LoadOptions(config_file);
	
	Mesh::VertexIt vi = m->VertexBegin(), ve = m->VertexEnd();
	Vec3 bl = (*vi)->Coord(), tr = (*vi)->Coord();
	for (; vi!=ve; ++vi) {
		Vec3 coord = (*vi)->Coord();
		for (int j=0; j<3; ++j) {
			bl[j] = std::min(bl[j], coord[j]);
			tr[j] = std::max(tr[j], coord[j]);
		}
	}
	std::cerr << "Top-right  : " << tr[0] << ", " << tr[1] << ", " << tr[2] << "." << std::endl;
	std::cerr << "Bottom-left: " << bl[0] << ", " << bl[1] << ", " << bl[2] << "." << std::endl;
	std::cerr << "Difference : " << tr[0]-bl[0] << ", " << tr[1]-bl[1] << ", " << tr[2]-bl[2] << "." << std::endl;
	std::cerr << "Area: " << (area=((tr[0]-bl[0])*(tr[1]-bl[1]))) << "." << std::endl;
	
	// lets set bc indicators
	top = tr[2];
	bottom = bl[2];
	len = top-bottom;
	std::cerr << "len is:" << len << std::endl;
	bottom_var *= len;
	top_var *= len;
	SetBC(); // we need boundary conditions.
	// compute the number of z-elements
	m_size=100;
	kernel_b=80.0; // kernel for Gaussian-kernel smoothing
	Coords=Eigen::VectorXd::LinSpaced(m_size,bottom,top);
	
	// now we can index...
	std::cerr << "Indexing " << m->VertexSize() << " vertices, ";
	vi = m->VertexBegin();
	N_dof = 0;
	// count basis functions
	for (; vi!=ve; ++vi)
		for (int j=0; j<3; ++j) if ( !(*vi)->DirBdry(j) ) ++N_dof;
	
	idx_mutex = std::vector<std::mutex>(N_dof);
	std::cerr << N_dof << " interior degrees of freedom, " << 3*m->VertexSize()-N_dof << " Dirichlet boundary... ";
    
	int idx = 0, idx_bdry = 0,idx_ref=0;
	vi = m->VertexBegin();
	for (; vi!=ve; ++vi) {
				(*vi)->SetIndex_ref(idx_ref);
			++idx_ref;		
		for (int j=0; j<3; ++j) {
	if ( !(*vi)->DirBdry(j) ) {
		(*vi)->SetIndex(j, idx);
		++idx;
	} else 	{
		(*vi)->SetIndex(j, idx_bdry);
		++idx_bdry;
	 }
 }
}
	std::cerr << "done; ";
	
	std::cerr << "Preparing " << m->TetSize() << " Tets... ";
	N_tet = 0;
	Mesh::TetIt ti = m->TetBegin(), te = m->TetEnd();
	for (; ti!=te; ++ti) {
		(*ti)->Init_vol();
		(*ti)->Init_grad_s();
		mesh_sizes.push_back(	(*ti)-> Init_mesh_size());
		++N_tet;
	}
		
	size_t elpth = ceil( (double)N_tet/numThreads);
		
	std::cerr << "Preparing " << numThreads << " threads... ";
	ti = m->TetBegin();
	for ( int i=0; i<numThreads; ++i ) {
		std::pair< Mesh::TetIt, Mesh::TetIt > bounds;
		bounds.first = ti;
		int j = 0;
		while (j<elpth && ti!=te) {++j; ++ti;}
		bounds.second = ti;
		tet_th.push_back(bounds);
	}

#ifdef EIGEN_HAS_OPENMP
	std::cerr << "Eigen is running in parallel... ";
	Eigen::setNbThreads(numThreads);
	Eigen::initParallel();
	omp_set_num_threads(numThreads); 
#endif 
	std::cerr << "ok; ";
	
	
	KTL_Chol=SpMat(m->VertexSize(),m->VertexSize());
	Init_Coords();
	
	// Performing Cholesky Decomposition for density variation; the decomposition needs to be performed only once 
	std::cerr << "Cholesky 1... ";
	CholeskyLoop();
	
	Eigen::SimplicialLLT<SpMat> llt;
 	llt.compute(KTL);
 	std::cerr<< "done" <<std::endl;
 	KTL_Chol=llt.matrixL();
 	
 	// Performing Cholesky Decomposition for geometric perturbations; the decomposition needs to be performed only once
 	std::cerr << "Cholesky 2... "; 
 	Geo_CholeskyLoop();
	KTL_Cholnew1= Mat(m_size,m_size);
 	KTL_Cholnew2= Mat(m_size,m_size);
	KTL_Cholnew_shear= Mat(m_size,m_size);
 	KTL_Cholnew_scal= Mat(m_size,m_size);
 
 
 
	for (int i=1; i<2; ++i){
	
	LLT<Mat> lltOfA(KTL_new_scal);
	KTL_Cholnew_scal= lltOfA.matrixL(); 
		 	}
		 	
	 for(int i=1; i< 2; ++i){	
	  LLT<Mat> lltOfA(KTL_new_shear);
	  KTL_Cholnew_shear= lltOfA.matrixL();
	}

	for (int i=1; i<2; ++i){
	LLT<Mat> lltOfA(KTL_new1);
	KTL_Cholnew1= lltOfA.matrixL(); 
		 	}
		 	
		 	
	LLT<Mat> lltOfA(KTL_new2);
	KTL_Cholnew2= lltOfA.matrixL();  
	std::cerr<< "Done" << std::endl;
	U_Scal=Vec::Ones(m->VertexSize());
	Z = Vec::Zero(N_dof);
	
	X1 = Vec::Zero(m->VertexSize());
  	X2 = Vec::Zero(m->VertexSize());
	X3 = Vec::Zero(m->VertexSize());
	U_Db = Vec::Zero(3*m->VertexSize()-N_dof);
	FNeu = Vec::Zero(N_dof);
	
	vi = m->VertexBegin();
	for (; vi!=ve; ++vi)
		{
				(*vi)->Attach_u_scal(&U_Scal[(*vi)->Index_ref()]);
		
		for (int j=0; j<3; ++j) 
	{
			
			if (!(*vi)->DirBdry(j)) (*vi)->Attach_u(j, &Z[(*vi)->Index(j)]);
			else (*vi)->Attach_u(j, &U_Db[(*vi)->Index(j)] );

	}
}

	InitBC();
	
}


void ImplicitPDESystem::Init2(std::string config_file) {
	
	//assert(config_file!="");
	// first thing, if we are given a file to init from, we load this data
	LoadOptions(config_file);
	
	Mesh::VertexIt vi = m->VertexBegin(), ve = m->VertexEnd();
	Vec3 bl = (*vi)->Coord(), tr = (*vi)->Coord();
	for (; vi!=ve; ++vi) {
		Vec3 coord = (*vi)->Coord();
		for (int j=0; j<3; ++j) {
			bl[j] = std::min(bl[j], coord[j]);
			tr[j] = std::max(tr[j], coord[j]);
		}
	}
	std::cerr << "Top-right  : " << tr[0] << ", " << tr[1] << ", " << tr[2] << "." << std::endl;
	std::cerr << "Bottom-left: " << bl[0] << ", " << bl[1] << ", " << bl[2] << "." << std::endl;
	std::cerr << "Difference : " << tr[0]-bl[0] << ", " << tr[1]-bl[1] << ", " << tr[2]-bl[2] << "." << std::endl;
	std::cerr << "Area: " << (area=((tr[0]-bl[0])*(tr[1]-bl[1]))) << "." << std::endl;
	
	// lets set bc indicators
	top = tr[2];
	bottom = bl[2];
	len = top-bottom;
	std::cerr << "len is:" << len << std::endl;
	bottom_var *= len;
	top_var *= len;
	SetBC(); // we need boundary conditions.
	
	// now we can index...
	std::cerr << "Indexing " << m->VertexSize() << " vertices, ";
	vi = m->VertexBegin();
	N_dof = 0;
	// count basis functions
	for (; vi!=ve; ++vi)
		for (int j=0; j<3; ++j) if ( !(*vi)->DirBdry(j) ) ++N_dof;
	
	idx_mutex = std::vector<std::mutex>(N_dof);
	std::cerr << N_dof << " interior degrees of freedom, " << 3*m->VertexSize()-N_dof << " Dirichlet boundary... ";
    
	int idx = 0, idx_bdry = 0,idx_ref=0;
	vi = m->VertexBegin();
	for (; vi!=ve; ++vi) {
				(*vi)->SetIndex_ref(idx_ref);
			++idx_ref;		
		for (int j=0; j<3; ++j) {
	if ( !(*vi)->DirBdry(j) ) {
		(*vi)->SetIndex(j, idx);
		++idx;
	} else 	{
		(*vi)->SetIndex(j, idx_bdry);
		++idx_bdry;
	 }
 }
}
	std::cerr << "done; ";
	
	
	std::cerr << "Preparing " << m->TetSize() << " Tets... ";
	N_tet = 0;
	Mesh::TetIt ti = m->TetBegin(), te = m->TetEnd();
	for (; ti!=te; ++ti) {
		(*ti)->Init_vol();
		(*ti)->Init_grad_s();
		mesh_sizes.push_back(	(*ti)-> Init_mesh_size());
		++N_tet;
	}
		
	size_t elpth = ceil( (double)N_tet/numThreads);
		
	std::cerr << "Preparing " << numThreads << " threads... ";
	ti = m->TetBegin();
	for ( int i=0; i<numThreads; ++i ) {
		std::pair< Mesh::TetIt, Mesh::TetIt > bounds;
		bounds.first = ti;
		int j = 0;
		while (j<elpth && ti!=te) {++j; ++ti;}
		bounds.second = ti;
		tet_th.push_back(bounds);
	}

#ifdef EIGEN_HAS_OPENMP
	std::cerr << "Eigen is running in parallel... ";
	Eigen::setNbThreads(numThreads);
	Eigen::initParallel();
	omp_set_num_threads(numThreads); 
#endif 
	std::cerr << "ok; ";
	
	Z = Vec::Zero(N_dof);
	U_Scal=Vec::Ones(m->VertexSize());
	Prep_Norm();
	U_Scal-=KTL_Chol*C_lognorm;
	
	X1 = Vec::Zero(m->VertexSize());
  	X2 = Vec::Zero(m->VertexSize());
	X3 = Vec::Zero(m->VertexSize());
	U_Db = Vec::Zero(3*m->VertexSize()-N_dof);
	FNeu = Vec::Zero(N_dof);
	
	vi = m->VertexBegin();


	for (; vi!=ve; ++vi)
		{
				(*vi)->Attach_u_scal(&U_Scal[(*vi)->Index_ref()]);
		
		for (int j=0; j<3; ++j) 
	{
			
			if (!(*vi)->DirBdry(j)) (*vi)->Attach_u(j, &Z[(*vi)->Index(j)]);
	else (*vi)->Attach_u(j, &U_Db[(*vi)->Index(j)] );

	}
}
	
	std::cerr << "ok; ";
	InitBC();
}

void ImplicitPDESystem::Geo_CholeskyLoop() {

std::vector<T> vals_ktl1, vals_ktl2;
double x1,y1,z1;
double x2,y2,z2;
KTL_new1=Mat(m_size,m_size);
KTL_new2=Mat(m_size,m_size);
KTL_new_scal=Mat(m_size,m_size);
KTL_new_shear=Mat(m_size,m_size);
double b1= m_size;	

	for (int i=0; i < m_size; ++i) {

			double b=i;
			z1=(b/b1);	
			for (int j=0;j < m_size; ++j) {
				
				double c=j;
				z2= c/b1;
											
				// Computing entries of the covariance matrix for geomertic perturbations
				double ktl1 = exp(-(abs(z1-z2)/0.0268));
				double ktl2 = exp(-(abs(z1-z2)/0.0268));
				double ktl_scal = exp(-(abs(z1-z2)/0.0268));
				double ktl_shear = exp(-(abs(z1-z2)/0.0268));
								
				KTL_new1(i,j)=ktl1;
				KTL_new2(i,j)=ktl2;
				KTL_new_scal(i,j)=ktl_scal;
				KTL_new_shear(i,j)=ktl_shear;
			}
											

	}
				
}				


void ImplicitPDESystem::CholeskyLoop() {

std::vector<T> vals_ktl; 
double x1,y1,z1;
double x2,y2,z2;

	for (int i=0; i < m->VertexSize() ; ++i) {

			
					 
					x1=X_Coord[i];
					y1=Y_Coord[i];
					z1=Z_Coord[i];
					
					
				for (int j=0;j < m->VertexSize(); ++j) {

					x2=X_Coord[j];
					y2=Y_Coord[j];
					z2=Z_Coord[j];
					
				   	double ktl = pos_part(1.0- (sqrt(sqr(x1-x2)+sqr(y1-y2)+sqr(z1-z2)))/lc_dens);
				        ktl*=sqr(ktl);
				        
					if(abs(ktl) > 0.0)
								{
											
									vals_ktl.push_back( T(i, j, ktl) );	
								
								}	
					}
											

				 }
				 
					KTL=SpMat(m->VertexSize(),m->VertexSize());	
					KTL.setFromTriplets(vals_ktl.begin(), vals_ktl.end());	
					
}


void ImplicitPDESystem::Perform_Geo_Per() {

		std::vector<double> X,Y,Z,XYZ,Knots, HKLT,X_scal,Y_scal,X_shear,Y_shear;
		Vec eins =Vec::Ones(m-> VertexSize());	
		std::cerr<< "Performing Geometric perturbation..";
		Prep_Norm();
		Vec KTL_Chol1,KTL_Chol2,KTL_scal1,KTL_scal2,KTL_shear1,KTL_shear2;
		
		KTL_Chol1= sigma_new1*KTL_Cholnew1*C_norm1; 
		//KTL_Chol1=sigma_new1*C_norm1;
		
		KTL_Chol2 = sigma_new2*KTL_Cholnew2*C_norm2;
		//KTL_Chol2= sigma_new2*C_norm2; 
		
		KTL_scal1= sigma_scal1*KTL_Cholnew_scal*C_norm_scal1;
		//KTL_scal1= sigma_scal1*C_norm_scal1;
		
		KTL_scal2= sigma_scal2*KTL_Cholnew_scal*C_norm_scal2;
		//KTL_scal2= sigma_scal2*C_norm_scal2;
		
		KTL_shear1= sigma_shear1*KTL_Cholnew_shear*C_norm_shear1;
		//KTL_shear1= sigma_shear1*C_norm_shear1;
		
		KTL_shear2= sigma_shear2*KTL_Cholnew_shear*C_norm_shear2;
		//KTL_shear2= sigma_shear2*C_norm_shear2;

		for (int i=0; i<m_size; ++i){
				X.push_back(KTL_Chol1[i]);
				Y.push_back(KTL_Chol2[i]);
				X_scal.push_back(KTL_scal1[i]);
				Y_scal.push_back(KTL_scal2[i]);
				X_shear.push_back(KTL_shear1[i]);
				Y_shear.push_back(KTL_shear2[i]);
				Knots.push_back(Coords[i]);
				
			}
			
	X1 = Vec::Zero(m->VertexSize());
	X2 = Vec::Zero(m->VertexSize());
	X3 = Vec::Zero(m->VertexSize());
			

   // Perform Gaussian-kernel smoothing; currently it is required that X is already sorted	
   
	for ( int i = 0; i < m-> VertexSize(); ++i){
			
	X1[i] = (1.0+mu_scal1+GKernel_Smoothing(Knots,X_scal,Z_Coord[i],kernel_b))*X_Coord[i]+GKernel_Smoothing(Knots,Y_shear,Z_Coord[i],kernel_b)*Y_Coord[i] +GKernel_Smoothing(Knots,X,Z_Coord[i],kernel_b);

	X2[i] = (1.0+mu_scal2+GKernel_Smoothing(Knots,Y_scal,Z_Coord[i],kernel_b))*Y_Coord[i]+GKernel_Smoothing(Knots,X_shear,Z_Coord[i],kernel_b)*X_Coord[i] +GKernel_Smoothing(Knots,Y,Z_Coord[i],kernel_b);
	
 }

Mesh::VertexIt vi = m->VertexBegin(), ve = m->VertexEnd();
	
// change the values of the coordinate values; only for plane coordinates x1 and x2
	for (; vi!=ve; ++vi)
		{
		double * point;
		point = &((*vi)-> m_coord.x());
		*point =  X1[(*vi) -> Index_ref()];
		point = &((*vi)-> m_coord.y());
		*point =  X2[(*vi) -> Index_ref()];
			}
}

void ImplicitPDESystem::Assemble() {
	std::cerr << "K... ";
	PrepK();
	std::cerr << "ok; "; 
}


// Generate random numbers V^i for computing density variation and geometric perturbation
// via L*V^i using Cholesk decomposition
void ImplicitPDESystem::Prep_Norm() {

			double trans_log,trans1, trans2,trans3,trans4,trans_scal1,trans_scal2,trans_shear1,trans_shear2;	

			C_lognorm=Vec::Zero(m->VertexSize());
			C_norm1=Vec::Zero(m_size);
			C_norm2=Vec::Zero(m_size);
			C_norm3=Vec::Zero(m_size);
			C_norm4=Vec::Zero(m_size);
			C_norm_shear1=Vec::Zero(m_size);
			C_norm_shear2=Vec::Zero(m_size);
			C_norm_scal1=Vec::Zero(m_size);
			C_norm_scal2=Vec::Zero(m_size);
			
			// numbers for geomertic perturbation
			for (int i=0; i < m_size; ++i) {
			
					trans1 = distribution_norm1(generator_norm1);
					trans2 = distribution_norm1(generator_norm2);
					trans_scal1 = distribution_norm1(generator_norm_scal1);
					trans_scal2 = distribution_norm1(generator_norm_scal2);
					trans_shear1 = distribution_norm1(generator_norm_shear1);
					trans_shear2 = distribution_norm1(generator_norm_shear2);
							
					C_norm1[i]+= trans1; 
					C_norm2[i]+= trans2;
					C_norm_scal1[i]+=trans_scal1;
					C_norm_scal2[i]+=trans_scal2;
					C_norm_shear1[i]+=trans_shear1;
					C_norm_shear2[i]+=trans_shear2;
						
								
					}

			// numbers for density variation
			for (int i=0; i < m->VertexSize(); ++i) {
	
					trans_log = distribution_log(generator_lognorm);
					C_lognorm[i]+= trans_log;
						
								
					}
	}

		

void ImplicitPDESystem::KLoop ( SpMat* th_k, SpMat* th_k1, Vec* th_b,Vec *th_b1, Mesh::TetIt ti, Mesh::TetIt te ) {
	
	std::vector<T> vals_k,vals_k1;
	*th_b = Vec::Zero(N_dof);
	*th_b1 = Vec::Zero(N_dof);
	
	Vec3 grad_sj, grad_si;
	double u_scal[NumIntPts];
	
	for (; ti!=te; ++ti) {
			(*ti)-> Calc_u_scal(u_scal);
		for (int bj=0; bj<4; ++bj) {
			
			(*ti)->Calc_grad_s(bj, grad_sj);
			Vertex* vj = (*ti)->v(static_cast<VertexName>(bj));
			
			for (int j=0; j<3; ++j) {
				int idx_j = vj->Index(j);
				
				if (!vj->DirBdry(j)) {
					for (int bi=0; bi<4; ++bi) {
						
						(*ti)->Calc_grad_s(bi, grad_si);
						Vertex* vi = (*ti)->v(static_cast<VertexName>(bi));
						
						for (int i=0; i<3; ++i) {
							if (vi->DirBdry(i)) continue;
							int idx_i = vi->Index(i);
							//if (idx_i < idx_j) continue;
			
							double k = 0.0;
							double k1=0.0;

						
					
							for (int l=0; l<3; ++l) {
								for (int m=0; m<3; ++m) {
									k += C(j,l,i,m)*grad_sj[l]*grad_si[m] * (*ti)->Vol();

									for (int k=0; k<NumIntPts; ++k)
							{
									k1+= C(j,l,i,m)*u_scal[k]*grad_sj[l]*grad_si[m]*GaussWeights[k]* (*ti) -> Vol();
							}
								}
							}
							
							//k += j==i ? dot(grad_sj,grad_si) * (*ti)->Vol() : 0.0;
							vals_k.push_back( T(idx_i, idx_j, k) );
							vals_k1.push_back( T(idx_i,idx_j,k1) );
						}
					}
				} else {
					double c_j = vj->u(j);
					for (int bi=0; bi<4; ++bi) {
						
						(*ti)->Calc_grad_s(bi, grad_si);
						Vertex* vi = (*ti)->v(static_cast<VertexName>(bi));
						
						for (int i=0; i<3; ++i) {
						
							if (vi->DirBdry(i)) continue;
							int idx_i = vi->Index(i);
					
							double b = 0.0;
							double b1=0.0;
							
							for (int l=0; l<3; ++l) {
								for (int m=0; m<3; ++m) {
									b -= c_j*C(j,l,i,m)*grad_sj[l]*grad_si[m] * (*ti)->Vol();
		
								for (int k=0; k<NumIntPts; ++k)
								{
										b1 -= u_scal[k]*c_j*C(j,l,i,m)*grad_sj[l]*grad_si[m]*GaussWeights[k] * (*ti)->Vol();
								}
								}
							}
							
							(*th_b)[ idx_i ] += b;
							(*th_b1)[idx_i] += b1;	
						}
					
					}
				}
			}
		
		}
	}

	(*th_k).setFromTriplets( vals_k.begin(), vals_k.end() );	
	(*th_k1).setFromTriplets( vals_k1.begin(), vals_k1.end() );	
	
}

void ImplicitPDESystem::PrepK() {
	std::vector<SpMat> th_k,th_k1;
	std::vector<Vec> th_b,th_b1;

	for ( int j = 0; j < numThreads; ++j ) {
		th_k.push_back( SpMat(N_dof, N_dof) );
		th_k1.push_back( SpMat(N_dof, N_dof) );
		th_b.push_back( Vec() );
		th_b1.push_back( Vec() );
	}
  	std::cerr<< "running" << std::endl;
	std::vector<std::thread> threads;
	for ( int j = 0; j < numThreads; ++j ) 
		threads.push_back( std::thread( &ImplicitPDESystem::KLoop, this, 
	&th_k[j],&th_k1[j], &th_b[j], &th_b1[j], tet_th[j].first, tet_th[j].second)  );
	// join threads
	for (auto &thread : threads) thread.join();

	K = SpMat(N_dof,N_dof);
	K_delta= SpMat(N_dof,N_dof);
	B = Vec::Zero(N_dof);
	B1 = Vec::Zero(N_dof);
	for (int j = 0; j < numThreads; ++j) {
		K += th_k[j];
		K_delta += th_k1[j];
		B += th_b[j];
		B1 += th_b1[j];
	}
	K.makeCompressed();
	K_delta.makeCompressed();
}


void ImplicitPDESystem::CalcFNeu() {
	
	Mesh::FaceIt fi = m->BdryFaceBegin(), fe = m->BdryFaceEnd();
	for (; fi!=fe; ++fi) {
		for (int j=0; j<3; ++j) {
			if (!(*fi)->NeuBdry(j)) continue;
			Vertex *va = (*fi)->a(), *vb = (*fi)->b(), *vc = (*fi)->c();
			Vec3 ca = va->Coord(), cb = vb->Coord(), cc = vc->Coord();
			Vec3 fa = NeumannBC(ca), fb = NeumannBC(cb), fc = NeumannBC(cc);
			Vec3 f = (*fi)->Area()*1.0/3.0*(fa+fb+fc);
			
			if (!(va->DirBdry(j))) FNeu[va->Index(j)] += 1.0/3.0 * f[j];
			if (!(vb->DirBdry(j))) FNeu[vb->Index(j)] += 1.0/3.0 * f[j];
			if (!(vc->DirBdry(j))) FNeu[vc->Index(j)] += 1.0/3.0 * f[j];
			
			
			
		}
		
	}
	
	
}


void ImplicitPDESystem::SolveWithGuess() {
	
	std::cerr << "Calc Neumann-force...";
	CalcFNeu();
	B1 += FNeu;
	std::cerr << "done." << std::endl;
	double t1,t2; 
        t1= omp_get_wtime();
	std::cerr << "Solver... ";
	Eigen::ConjugateGradient<SpMat, Eigen::Lower | Eigen::Upper> cg;
	//cg.setMaxIterations(0.1*N_dof);
	cg.setTolerance(1e-5);
	cg.compute(K_delta);
	
	std::cerr << "Solving... ";
	Z = cg.solveWithGuess(B1,Z0);
	std::cerr << "done." << std::endl;

	t2 = omp_get_wtime();
	std::cout<< "time needed=" << t2-t1<< std::endl; 

	
}

void ImplicitPDESystem::Solve() {
	
	std::cerr << "Calc Neumann-force...";
	CalcFNeu();
	B += FNeu;
	std::cerr << "done." << std::endl;
	double t1,t2; 
	t1= omp_get_wtime();
	std::cerr << "Solver... ";
	Eigen::ConjugateGradient<SpMat, Eigen::Lower | Eigen::Upper> cg;
	cg.setTolerance(1e-5);
	cg.compute(K);
	
	std::cerr << "Solving... ";
	Z = cg.solve(B);
	std::cerr << "done." << std::endl;

	t2 = omp_get_wtime();
	std::cout<< "time needed" << t2-t1<< std::endl; 

	Z0=Vec::Zero(N_dof);	
	Z0=Z;
}


void ImplicitPDESystem::ELoop ( double* th_e, Mesh::TetIt ti, Mesh::TetIt te ) {
	*th_e = 0;
	Vec3 grad_sj, grad_si;
	double u_scal[NumIntPts];
	
	for (; ti!=te; ++ti) {
	                     (*ti)-> Calc_u_scal(u_scal);
		for (int bj=0; bj<4; ++bj) {
			
			(*ti)->Calc_grad_s(bj, grad_sj);
			Vertex* vj = (*ti)->v(static_cast<VertexName>(bj));
			
			for (int j=0; j<3; ++j) {
			
					for (int bi=0; bi<4; ++bi) {
						
						(*ti)->Calc_grad_s(bi, grad_si);
						Vertex* vi = (*ti)->v(static_cast<VertexName>(bi));
						
						for (int i=0; i<3; ++i) {
							
							for (int l=0; l<3; ++l) {
								for (int m=0; m<3; ++m) {
								for (int k=0; k<NumIntPts; ++k)
									{
										*th_e += 0.5*C(j,l,i,m)*u_scal[k]*GaussWeights[k]*grad_sj[l]*grad_si[m]*vi->u(i)*vj->u(j) * (*ti)->Vol();
									}
								}
							}
							
						}
					}

			}
		
		}
	}
}

// compute elastic energy
double ImplicitPDESystem::CalcE() {
	std::vector<double> th_e;
	for ( int j = 0; j < numThreads; ++j ) {
		th_e.push_back( 0.0 );
	}
  
	std::vector<std::thread> threads;
	for ( int j = 0; j < numThreads; ++j ) 
		threads.push_back( std::thread( &ImplicitPDESystem::ELoop, this, 
	&th_e[j], tet_th[j].first, tet_th[j].second)  );
	// join threads
	for (auto &thread : threads) thread.join();
  
	double  e = 0.0;
	for (int j = 0; j < numThreads; ++j) {
		e += th_e[j];
	}
	return e;
}


// compute effective Young's modulus
void ImplicitPDESystem::CalcYoungs(int k) {
	
	double e = CalcE();
	
	std::cerr << "Energy: " << e << "." << std::endl;
	std::cerr << "Ym: " << 2.0*len*e/(area*sqr(0.5)) << "." << std::endl;
	
	/*std::fstream dataablage; 
	dataablage.open("daten_gyroid"+to_string(k)+".dat", ios::app); 
	dataablage << "Ym ="<< 2.0*len*e/(area*sqr(0.5)) << std::endl;
	dataablage << "Energie ="<< e << std::endl;  
	dataablage.close(); */	
		
}


// load options regarding shear and bulk modulus etc.
void ImplicitPDESystem::LoadOptions(std::string fname) {
	std::ifstream is;
	is.open(fname.c_str());

	double K, mu;
	
	std::string line;
	while( std::getline(is, line) ){
		
		boost::char_separator<char> sep(" ");
		boost::tokenizer< boost::char_separator<char> > tok(line, sep);
		boost::tokenizer< boost::char_separator<char> >::iterator ti = tok.begin(), te = tok.end();
		
		if (ti==te) continue; //empty line.
		
		if ( *ti == "th" ) numThreads = std::stoi(*(++ti));
		if ( *ti == "K" ) K = std::stod(*(++ti));
		if ( *ti == "mu" ) mu = std::stod(*(++ti));
		if ( *ti == "t_var" ) top_var = std::stod(*(++ti));
		if ( *ti == "b_var" ) bottom_var = std::stod(*(++ti));
	}
	C = ElMod(K,mu);
}



