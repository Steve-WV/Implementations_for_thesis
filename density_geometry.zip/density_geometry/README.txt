Guidelines how to use the code: 

REQUIREMENTS:
 - Cmake version no less than 3.5
 - A suitable C++ compiler
 - The linear algebra library Eigen
 - The Boost libraries


After compilation using cmake and make, a target called "s2d" is produced 
which can be executed by: el3_s3d -f [path to]/generated2.1.objv -c  [path to]/default2.cfg

By this the simulation is started on the 3d-gyroid domain O_h

The main code of the simulation is provided in the executable 
file "pde.cpp" and "main.cpp".

In "main.cpp" the relevant parameters are described 
in lines 12-22, where e.g. the different standard deviations in the fuzzy
representation of the geometric perturbations are set

The default configuration of the code is appropriate to
the experiment provided in the thesis Section 14.
