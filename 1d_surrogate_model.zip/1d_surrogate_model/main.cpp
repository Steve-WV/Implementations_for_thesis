#include "ode.hpp"
#include <iomanip>
#include <getopt.h>
#include <iostream>
#include <fstream>
#include <cmath>

int main(int argc, char *argv[]) {

ODESystem ode;


ode.Solve();

}
